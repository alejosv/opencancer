# mindmaps-prostate
Mindmaps for information modelling prostate cancer datasets
